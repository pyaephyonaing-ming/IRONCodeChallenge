﻿using System.Text;

namespace OldPhoneKeypad
{
    class Program
    {
        static void Main(string[] args)
        {
            bool running = true;

            while(running)
            {
                Console.Write("Enter keypad input using 0-9, * or space (# must be included at the end): ");
                StringBuilder inputText = new StringBuilder();

                while(true)
                {
                    var key = Console.ReadKey(intercept: true);
                    char c = key.KeyChar;

                    if(c == '#' || c == '*' || c == ' ' || (c >= '0' && c <= '9'))
                    {
                        if(c == '#')
                        {
                            string input = inputText.ToString();
                            Console.WriteLine("#");
                            Console.WriteLine("OldPhonePad(\"" + input + "#\") => output: " + OldPhonePad(input));
                            break;
                        }
                        else
                        {
                            Console.Write(c);
                            inputText.Append(c);
                        }
                    }
                    else
                    {
                        Console.Write(c);
                        Console.WriteLine($"\nInvalid Character '{c}'. Please enter only digits 0-9, *, space or #.");
                        inputText.Clear();
                        Console.Write($"\nEnter keypad input using 0-9, * or space (# must be included at the end): ");
                    }
                }

                string ans = "";

                while(true)
                {
                    Console.Write("\nDo you want to try again? (Y/N): ");
                    ans = Console.ReadLine().Trim().ToLower();

                    if(ans == "y")
                    {
                        Console.WriteLine();
                        break;
                    }
                    else if(ans == "n")
                    {
                        Console.WriteLine("Thank You. Goodbye!");
                        running = false;
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. Please enter 'Y' or 'N'.");
                    }
                }
            }
        }

        public static string OldPhonePad(string input)
        {
            Dictionary<char, string> keypadvalues = new Dictionary<char, string>()
            {
                {'1', "&'("},
                {'2', "ABC"},
                {'3', "DEF"},
                {'4', "GHI"},
                {'5', "JKL"},
                {'6', "MNO"},
                {'7', "PQRS"},
                {'8', "TUV"},
                {'9', "WXYZ"},
                {'0', " "}
            };

            StringBuilder output = new StringBuilder();
            char prev = '\0';
            int count = 0;

            foreach(char c in input)
            {
                if(c == ' ')
                {
                    if(prev != '\0' && keypadvalues.ContainsKey(prev))
                    {
                        int index = (count - 1) % keypadvalues[prev].Length;
                        output.Append(keypadvalues[prev][index]);
                    }
                    prev = '\0';
                    count = 0;
                }
                else if(c == '*')
                {
                    if(count > 0)
                    {
                        count = 0;
                        prev = '\0';
                    }
                    else if(output.Length > 0)
                    {
                        output.Length--;
                    }
                }
                else if(char.IsDigit(c))
                {
                    if(c == prev)
                    {
                        count++;
                    } 
                    else
                    {
                        if(prev != '\0' && keypadvalues.ContainsKey(prev))
                        {
                            int index = (count - 1) % keypadvalues[prev].Length;
                            output.Append(keypadvalues[prev][index]);
                        }
                        prev = c;
                        count = 1;
                    }
                }
            }

            if(prev != '\0' && keypadvalues.ContainsKey(prev))
            {
                int index = (count - 1) % keypadvalues[prev].Length;
                output.Append(keypadvalues[prev][index]);
            }

            return output.ToString();
        }
    }
}
